import { createApp } from 'vue'
import App from './App.vue'
import AppSample from './AppSample.vue'

console.log(`VUE : calling createApp`);
// createApp(AppSample).mount('#app');
createApp(App).mount('#app');

