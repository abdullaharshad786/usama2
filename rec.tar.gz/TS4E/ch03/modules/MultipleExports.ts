export class MultipleClass1 { }

export class MultipleClass2 { }