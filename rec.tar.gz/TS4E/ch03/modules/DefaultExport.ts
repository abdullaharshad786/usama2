export default function DefaultAdd(
    a: number, b: number) {
    return a + b;
}
export class ModuleNonDefaultExport { }