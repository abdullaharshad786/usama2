import * as _ from "underscore";

// we need to install @types/underscore or this will cause a compilation error.