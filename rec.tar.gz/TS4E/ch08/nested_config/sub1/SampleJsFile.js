function testJsFunction(value) {
    console.log(`value`);
}