declare function testImplicityAny(): void;

function testNoParamType(value: string) { }

class TestAny {
    id: any;
}