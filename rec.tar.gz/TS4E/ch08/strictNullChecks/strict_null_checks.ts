let a: number | undefined;
let b = a;

