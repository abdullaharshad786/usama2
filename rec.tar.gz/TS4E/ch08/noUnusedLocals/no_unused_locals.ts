
function testFunction(input: string): boolean {
    // let test;
    // return false;
    let test = input;
    return test === "someValue";
} 