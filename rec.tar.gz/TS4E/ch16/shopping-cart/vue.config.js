// module.exports = {
//     // options...
//     publicPath: "vue-app"
// }